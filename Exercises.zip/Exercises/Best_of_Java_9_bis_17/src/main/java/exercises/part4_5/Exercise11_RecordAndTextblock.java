package exercises.part4_5;

import java.time.LocalDate;

/**
 * Beispielprogramm für den Workshop "Best of Java 9, 10 und 11" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018/2019 by Michael Inden 
 */
public class Exercise11_RecordAndTextblock {

	record Person(String firstName, String lastName, LocalDate birthday) {}
	
	public static void main(String[] args) 
	{
		Person mike = new Person("Michael", "Inden", LocalDate.of(1971, 2, 7)); 
		
		System.out.println(mike);
		//System.out.println(mike.toXml());
		//System.out.println(mike.toJSON());
	}
}
