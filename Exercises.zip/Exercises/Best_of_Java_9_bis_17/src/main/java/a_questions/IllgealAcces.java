package a_questions;

import java.io.IOException;

public class IllgealAcces
{

    public static void main(String[] args) throws IOException
    {
        // jdk.internal.net.http.CookieFilter
        com.sun.net.httpserver.HttpServer server = com.sun.net.httpserver.HttpServer.create();
        
//        Base64.
    }
}
