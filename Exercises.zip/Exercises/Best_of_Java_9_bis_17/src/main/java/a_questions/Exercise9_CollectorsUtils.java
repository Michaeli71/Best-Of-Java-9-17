package a_questions;

import java.util.function.Predicate;
import java.util.stream.Collector;

/**
 * Beispielprogramm für den Workshop "Java 9 Hands On" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018 by Michael Inden 
 */
public class Exercise9_CollectorsUtils 
{
	public static <T, A, R> Collector<T, A, R> filtering(final Predicate<? super T> filter, 
			                                             final Collector<T, A, R> collector) 
	{
		  return Collector.of(
		      collector.supplier(),
		      
		      // TRICK
		      (accumulator, input) -> {
		         if (filter.test(input)) {
		            collector.accumulator().accept(accumulator, input);
		         }
		      },		      
		      
		      collector.combiner(),
		      collector.finisher());
	}
}
