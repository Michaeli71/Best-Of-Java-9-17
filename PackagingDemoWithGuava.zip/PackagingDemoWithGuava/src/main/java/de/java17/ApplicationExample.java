package de.java17;

import java.util.List;

import javax.swing.JOptionPane;

import com.google.common.base.Joiner;

/*
 * ^CMichaels-MBP-3:PackagingDemo michaeli$ jpackage --input target/   --name JPackageDemoApp 
 *   --main-jar PackagingDemoExamples-1.0-SNAPSHOT.jar 
 *     --main-class de.java17.ApplicationExample  
 *      --type dmg   --java-options '--enable-preview'
 */
public class ApplicationExample {

	public static void main(String[] args) {
		
		System.out.println("First JPackage");
		
		Joiner joiner = Joiner.on(":");
		String result = joiner.join(List.of("Michael", "mag", "Python"));
		System.out.println(result);
		
		JOptionPane.showConfirmDialog(null, result);
	}
}
